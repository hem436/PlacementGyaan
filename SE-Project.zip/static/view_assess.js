const base_url = window.location.origin
//import load_post from "./posts.js"

const new_post=new Vue({
    el:"#app",
    data() {
        return {
            myprofile:JSON.parse(sessionStorage.getItem('myprofile')),
            apti_id:JSON.parse(sessionStorage.getItem('question_details')).apti_id,
            question_list:JSON.parse(sessionStorage.getItem('question_details')).questions,
            showAnswers:false,
        }
    },
    methods: {
        'submitApti': function(){
            // console.log("create post function");
            const formData = new FormData();
                formData.append('user_id',this.myprofile.user_id)
                formData.append("experiences", this.experiences)
                formData.append('tips',this.tips)
            fetch(`${base_url}/api/posts`,{
                method:'POST',
                body:formData,
            })
            .then((res)=>{
                window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
            })
            .catch((error)=>{alert(error.message)})
        },
        dashBoard:function () {
            window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
        },
    },
    created() {
    },
})