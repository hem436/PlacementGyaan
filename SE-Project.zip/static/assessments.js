const base_url = window.location.origin

const all_post = new Vue({
    el:"#app",
    data(){
        return{
        myprofile:JSON.parse(sessionStorage.getItem('myprofile')),
        apti_list:[],
        quest_list:[],
        currentPage:1,
        }
    },
    computed: {
        totalPages(){
            return this.apti_list.length
        },
        currentPost(){
            return this.apti_list[this.currentPage-1] || {}
        }
    },
    methods: {
        nextPage:function(){
            // console.log('inside next Pae');
            if (this.currentPage < this.totalPages){this.currentPage++}
        },
        previousPage:function(){
            // console.log('inside pre page');
            if (this.currentPage > 1){this.currentPage--}
        },
        deletePost:function(){
            fetch(`${base_url}/api/apti/${this.currentPost.post_id}`,{
                method:"DELETE",
            })
            location.reload()
        },
        createApti:function(){
            const formData = new FormData();
                    formData.append('user_id',this.myprofile.user_id)
                fetch(`${base_url}/api/apti`,{
                    method:'POST',
                    body:formData,
                })
                .then((res)=>{if(res.ok){return res.json()}
                        else{console.log('result',res.text);throw new Error(res.text())}})
                .then((data)=>{
                    sessionStorage.setItem('apti_id',JSON.stringify(data.apti_id))
                    window.location.href=`${base_url}/create_assessment`
                })
                .catch((error)=>{alert(error.message)})
        },
        dashBoard:function () {
            window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
        },
        mergeArray:function(){
            const idToQuest = {};
            for (const obj of this.quest_list) {
                idToQuest[obj.apti_id] = obj.questions;
            }

            // Update list1 with marks from list2
            for (const obj of this.apti_list) {
                if (idToQuest[obj.apti_id] !== undefined) {
                obj.question_details = idToQuest[obj.apti_id];
                }
            }
        },
        load_quest:function(apti_id) {
            // console.log('71');
            fetch(`${base_url}/api/${apti_id}/test_q/0`,{
                method:"GET"
            })
            .then((res)=>{if(res.ok){return res.json()}
                        else{console.log(res.text());}})
            .then((data)=>{
                // console.log('78',data.quest_obj);
                const new_obj={'apti_id':apti_id,'questions':data.quest_obj}
                this.quest_list.push(new_obj)
                this.mergeArray();
                // console.log(this.apti_list);
            })
            .catch((err)=>{console.log(err.message)})
        },
        load_apti:function(){
            fetch(`${base_url}/api/apti`,{
                method:"GET"
            })
            .then((res)=>{if(res.ok){return res.json()}
                        else{console.log(res.text());}})
            .then((data)=>{
                data.aptis.forEach(element=>{
                    this.apti_list.push(element)
                    // console.log('line 93',element);
                    this.load_quest(element.apti_id)
                })
            })
            .catch((err)=>{ console.log(err.message);})
        },
        'deleteApti':function(){
            fetch(`${base_url}/api/apti/${this.currentPost.apti_id}`,{
                method:"DELETE",
            })
            location.reload()
        },
        viewAssessment:function(question_details) {
            sessionStorage.setItem('question_details',JSON.stringify(question_details))
            window.location.href=`${base_url}/view_assessment`
        }
    },
    created(){
        this.load_apti();
    },
})
