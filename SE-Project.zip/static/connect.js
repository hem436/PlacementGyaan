const base_url = window.location.origin

const new_post=new Vue({
    el:"#app",
    data() {
        return {
            myprofile:JSON.parse(sessionStorage.getItem('myprofile')),
            conn_list:JSON.parse(sessionStorage.getItem('conn_list')),
            match_list:[],
            keyword:''
        }
    },
    methods: {
        follow: function(item){
            console.log('inside follow');
            const formData = new FormData();
                formData.append('user',item.user_id)
                formData.append("follower", this.myprofile.user_id)
            fetch(`${base_url}/api/connection`,{
                method:'POST',
                body:formData
            })
            .then(() => {
                alert(`You are now following ${item.username}`)
                window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
            })
            .catch((err) => {alert(err.message)})
        },
        unfollow: function(item){
            fetch(`${base_url}/api/${item.user_id}/connection/${this.myprofile.user_id}`,{
                method:'DELETE',
            })
            .then((response) => {
                alert(`You are no longer following ${item.username}`)
                window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
            })
            .catch((err) => {alert(err.message)})
            },
        find:function(){
            // console.log('inside find');
            fetch(`${base_url}/api/search/${this.keyword}`,{
                method:'GET',
            })
            .then((res)=>{if(res.ok){return res.json()}
                        else{throw new Error(res.text())}})
            .then((data)=>{this.match_list=data.matches})
            .catch((err) => {alert(err.message)})
        },
        dashBoard:function () {
            window.location.href=`${base_url}/dashboard/${this.myprofile.user_id}`
        },
    },
    created() {
    },
})