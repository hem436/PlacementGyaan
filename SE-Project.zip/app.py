from flask_restful import Resource, Api, reqparse, fields, abort
from flask_cors import CORS
from flask import Flask, redirect, render_template, request, send_file, jsonify, json
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from functools import wraps
import pandas as pd
import os
from model import *


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///SE_project.sqlite3'
app.app_context().push()
db.init_app(app)
if not os.path.exists('./instance/SE_project.sqlite3'):
    print("creating database")
    db.create_all()
app.app_context().push()
api = Api(app)
CORS(app)
app.jinja_env.variable_start_string = '{{{'
app.jinja_env.variable_end_string = '}}}'


def save_image(picture):
    pic_name = secure_filename(picture.filename)
    pic_path = os.path.join('./static/', pic_name)
    picture.save(pic_path)
    return pic_name


def check_username(name):
    user = Users.query.filter_by(name=name).all()
    if user:
        return False
    return True


@app.route('/',methods=['GET'])
def base():
    if request.method == 'GET':
        return render_template('login.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        print(request.form)
        username = request.form['username']
        password = request.form['password']
        user = Users.query.filter_by(username=username, password=password).first()
        if user:
            return redirect(f'/dashboard/{user.user_id}')
        else:
            return render_template('login.html',error="Invalid username or password")


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html')
    else:
        print(request.form)
        username = request.form['username']
        password1 = request.form['password1']
        password2 = request.form['password2']
        if request.form['secret']:
            secret_key = request.form['secret']
            if secret_key == 'admin':
                user_type="admin"
            else:
                render_template('signup.html',error="Invalid secret key")
        else:
            user_type="user"
        if check_username(username) == False:
            return render_template('signup.html',error='Username already in user')
        if password1 != password2:
            return render_template('signup.html',error='Password not matching')
        new_user = Users(username=username,name=request.form['name'],education=request.form['education'],
                            work=request.form['work'],about=request.form['about'],password=request.form['password1'],
                            user_type=user_type)
        db.session.add(new_user)
        db.session.commit()
        return redirect('/')

@app.route('/dashboard/<int:user_id>')
def dashboard(user_id):
    user = Users.query.get(user_id)
    user_output_fields = {
                        'username':user.username,
                        'user_id': user.user_id,
                        'name': user.name,
                        'img': user.image,
                        'education': user.education,
                        'work': user.work,
                        'about': user.about,
                        'user_type': user.user_type
                    }
    return render_template('dashboard.html',myprofile=user_output_fields)

@app.route('/posts')
def posts():
    return render_template('posts.html')

@app.route('/assessments')
def assessment():
    return render_template('assessments.html')

@app.route('/create_assessment')
def create_assessment():
    return render_template('create_assessment.html')

@app.route('/search')
def search():
    return render_template('connect.html')

@app.route('/logout')
def logout():
    return redirect('/')

@app.route('/edit_post')
def edit_post():
    return render_template('edit_post.html')

@app.route('/view_assessment')
def view_assessment():
    return render_template('view_assess.html')


@app.route('/create_post')
def create_post():
    return render_template('create_post.html')

class Login_api(Resource):
    def post(self):
        json_data = request.get_json(force=True)
        username = json_data['username']
        password = json_data['password']
        user=Users.query.filter_by(name=username,password=password).first()
        if user:
            user_output_fields={
                'user_id':user.user_id,
                }
            return jsonify(user_output_fields)
        abort(404, message='Enter the credential correctly')

api.add_resource(Login_api,'/login')

class Users_api(Resource):
    def post(self):
        #print()
        contain_image=bool(int(request.form['contain_image']))
        username=request.form['username']
        password=request.form['password']
        education=request.form['education']
        work=request.form['work']
        about=request.form['about']
        user_type=request.form['user_type']
        img=''
        if contain_image:
                img=save_image(request.files['image'])
        if check_username(username)==False:
            return('Username aleready exists',400)
        new_user=Users(username=username, password=password,images=img,education=education,work=work,about=about,user_type=user_type)
        db.session.add(new_user)
        db.session.commit()
        return "user created", 201
    
    def put(self):
        user_id=request.form['user_id']
        # img=save_image(request.files['image'])
        user=Users.query.get(user_id)
        # user.img=img
        db.session.commit()
        return 'Picture changed',201

api.add_resource(Users_api,"/api/users")

class Posts_api(Resource):
    def get(self):                                                                   #incase we want all the post from any particular user
        posts=Posts.query.all()
        #print(posts)
        if posts:
            post_contents=[]
            for post in posts:
                p={
                    'post_id':post.post_id,
                    'experiences':post.experiences,
                    'likes':post.likes,
                    'dislikes':post.dislikes,
                    'tips':post.tips,
                    'created_at':post.created_at,
                    'created_by':Users.query.get(post.created_by).username
                }
                post_contents.append(p)
            #print(post_contents)
            return jsonify({
                'posts':post_contents
                })
        else:
            return "no post exist for this user",404
    
    
    def post(self):
        # print(request.form)
        # print(request.form['contain_image'],request.form['user_id'],request.form['tips'],request.form['experiences'])
        v_user=Users.query.get(request.form['user_id'])
        if v_user:
            time=datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            new_post=Posts(created_by=request.form['user_id'],likes=0,dislikes=0,tips=request.form['tips'],
                            created_at=time,experiences=request.form['experiences'])
            db.session.add(new_post)
            db.session.commit()
            return 'post successfully created', 201
        else:
            abort(400,message="enter a valid user id")
    
    
    def put(self):
        post=Posts.query.get(request.form['post_id'])
        if post:
            post.tips=request.form['tips']
            post.experiences=request.form['experiences']
            time=datetime.now().strftime("%d-%m-%Y tips%H:%M:%S")
            post.time=time
            db.session.commit()
            return 'ok',201
        else:
            abort(404,message="Post not found")

    
    def delete(self,post_id):
        post=Posts.query.get(post_id)
        if post:
            db.session.delete(post)
            db.session.commit()
            return 'deleted successfully', 201
        else:
            abort(404,message="no such post exists")

api.add_resource(Posts_api,'/api/posts','/api/posts/<int:post_id>')


class Post_comment_api(Resource):
    def get(self,post_id,user_id):
        post = Posts.query.filter_by(post_id=post_id).first()
        user = Users.query.filter_by(user_id=user_id).first()
        if post and user:
            comment = Post_comment.query.filter_by(post_id=post.post_id,user_id=user.user_id).first()
            q={
                'content':comment.content
            }
            return jsonify(q)
        else:
            abort(404,message="no such post exists")

    def post(self):
        post_id,user_id = request.form['post_id'],request.form['user_id']
        user = Users.query.filter_by(user_id=user_id).first()
        post = Posts.query.filter_by(post_id=post_id).first()
        if user and post:
            comm = Post_comment(user_id=user_id,post_id=post_id)
            db.session.add(comm)
            db.session.commit()
            return 'comment posted successfully', 201
        else:
            abort(404,message="worng credentials")

    def delete(self,post_id,user_id):
        comm = Post_comment.query.filter_by(user_id=user_id,post_id=post_id).first()
        if comm:
            db.session.delete(comm)
            db.session.commit()
            return 'comment deleted'
        else:
            abort(404,message="worng credentials")

api.add_resource(Post_comment_api, '/api/post_comm', '/api/<int:post_id>/post_comm/<int:user_id>')


class Apti_api(Resource):
    def get(self):                                                                   #incase we want all the post from any particular user
        aptis=Aptitude_test.query.all()
        # print(aptis)
        if aptis:
            apti_contents=[]
            for apti in aptis:
                p={
                    'apti_id':apti.apti_id,
                    'apti_name':apti.apti_name,
                    'likes':apti.likes,
                    'dislikes':apti.dislikes,
                    'created_at':apti.created_at,
                    'created_by':Users.query.get(apti.created_by).username
                }
                apti_contents.append(p)
            #print(post_contents)
            return jsonify({
                'aptis':apti_contents
                })
        else:
            return "no post exit for this user",404
    
    
    def post(self):
        user_id = request.form['user_id']
        v_user=Users.query.get(user_id)
        if v_user:
            time=datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            new_apti=Aptitude_test(created_by = v_user.user_id,likes=0,dislikes=0,created_at=time,
                                    apti_name='')
            db.session.add(new_apti)
            db.session.commit()
            apti=Aptitude_test.query.order_by(Aptitude_test.apti_id.desc()).first()
            return jsonify({'apti_id':apti.apti_id})
        else:
            abort(400,message="enter a valid user id")
    
    
    def put(self):
        apti_id = request.form['apti_id']
        apti=Aptitude_test.query.get(apti_id)
        if apti:
            time=datetime.now().strftime("%d-%aptim-%Y %H:%M:%S")
            apti.time=time
            db.session.commit()
            return 'ok',201
        else:
            abort(404,message="Post not found")

    
    def delete(self,apti_id):
        post=Aptitude_test.query.get(apti_id)
        if post:
            db.session.delete(post)
            db.session.commit()
            return 'deleted successfully', 201
        else:
            abort(404,message="no such post exists")

api.add_resource(Apti_api,'/api/apti','/api/apti/<int:apti_id>')


class Apti_comment_api(Resource):
    def get(self,apti_id,user_id):
        comm = Apti_comment.query.filter_by(apti_id = apti_id,user_id=user_id).first()
        if comm:
            q = {
                'content':comm.content
            }
            return jsonify(q)
        else:
            abort(404,message="wrong credentials")
    
    def post(self):
        apti_id,user_id = request.form['apti_id'],request.form['user_id']
        apti = Aptitude_test.query.get(apti_id)
        user = Users.query.get(user_id)
        if apti and user:
            content = request.form['content']
            comm = Apti_comment(apti_id = apti_id, user_id = user_id,content=content)
            db.session.add(comm)
            db.session.commit()
            return 'comment added successfully', 201
        else:
            abort(404,message="wrong credentials")
    
    def delete(self,apti_id,user_id):
        comm = Apti_comment.query.filter_by(apti_id = apti_id, user_id = user_id).first()
        db.session.delete(comm)
        db.session.commit()
    
api.add_resource(Apti_comment_api, '/api/apti_comm', '/api/<int:apti_id>/apti_comm/<int:user_id>','/api/apti_comm/<int:user_id>')


class Test_question_api(Resource):
    def get(self,apti_id,quest_id=0):
        if quest_id!=0:                                               #incase we want to fetch a particular post by user
            quest=Test_quest.query.filter_by(quest_id=quest_id,apti_id=apti_id).first()
            q={
                'question':quest.question,
            }
            return jsonify(q)
        else:                                                          #incase we want all the post from any particular user
            quests=Test_quest.query.filter_by(apti_id=apti_id).all()
            #print(posts)
            if quests:
                quests_contents=[]
                for quest in quests:
                    quests_contents.append({'question':quest.question,
                                            'answer':quest.answers,
                                            'type':quest.type})
                #print(post_contents)
                quest_obj={
                    'apti_id':apti_id,
                    'questions':quests_contents,
                    }
                return jsonify({'quest_obj':quest_obj})
            else:
                return "no post exit for this user",404
        
    def post(self):
        apti_id = request.form['apti_id']
        apti=Aptitude_test.query.get(apti_id)
        if apti:
            #print(json.loads(request.form['quest_list']))
            quest_list=json.loads(request.form['quest_list'])
            for i in quest_list:
                print(i)
                new_quest=Test_quest(apti_id=apti_id,question=i['question'],answers=i['answer'],
                                    type=i['type'])
                db.session.add(new_quest)
                db.session.commit()
            return 'question successfully created', 201
        else:
            abort(400,message="enter a valid aptitude id")

    def put(self):
        apti_id,quest_id = request.form['apti_id'],request.form['quest_id']
        quest=Test_quest.query.filter_by(apti_id=apti_id,quest_id=quest_id).first()
        if quest:
            if request.form['question']:
                quest.question=request.form['question']
            if request.form['type']:
                quest.type=request.form['type']
            db.session.commit()
            return 'question successfully changed', 201
        else:
            abort(400,message="enter a valid aptitude id or question id")
    
    def delete(self,quest_id):
        quest=Test_quest.query.get(quest_id)
        if quest_id:
            db.session.delete(quest)
            db.session.commit()
            return 'deleted successfully', 201
        else:
            abort(404,message="no such question exists")
api.add_resource(Test_question_api,'/api/test_q', '/api/<int:apti_id>/test_q/<int:quest_id>','/api/test_q/<int:quest_id>')



class Test_score_api(Resource):
    def get(self,apti_id,user_id):
        new = Test_score.query.filter_by(apit_id = apti_id, user_id = user_id).first()
        if new:                                               #incase we want to fetch a particular post by user
            
            q={
                'score':new.score
            }
            return jsonify(q)
        else:                                                          #incase we want all the post from any particular user
            return "no post exit for this user",404
        
    def post(self):
        apti_id,user_id = request.form['apti_id'],request.form['user_id']
        test = Aptitude_test.query.filter_by(apti_id=apti_id).first()
        user = Users.query.filter_by(user_id = user_id).first()
        if test and user:
            new_score = Test_score(apti_id = test.apti_id,stud_id = user.user_id,score = request.form['score'])
            db.session.add(new_score)
            db.session.commit()
            return 'question successfully created', 201
        else:
            abort(400,message="enter a valid aptitude id")

    def put(self):
        apti_id,user_id = request.form['apti_id'],request.form['user_id']
        new = Test_score.query.filter_by(apit_id = apti_id, user_id = user_id).first()
        if new:
            if request.form['score']:
                new.score = request.form['score']
            return 'question successfully changed', 201
        else:
            abort(400,message="enter a valid aptitude id or user id")
    
    def delete(self,apti_id,user_id):
        new = Test_score.query.filter_by(apit_id = apti_id, user_id = user_id).first()
        if new:
            db.session.delete(new)
            db.session.commit()
            return 'deleted successfully', 201
        else:
            abort(404,message="no such question exists")

api.add_resource(Test_score_api,'/api/score', '/api/<int:apti_id>/score/<int:user_id>')


class Connection_api(Resource):
    
    def get(self,user):
        user=Users.query.get(user)
        if user:
            connections=Connection.query.filter_by(following=user.user_id).all()
            l=[]
            for conn in connections:
                l.append(conn.user)
            conn_list={
                'connection':l
            }
            return jsonify(conn_list)
        else:
            abort(400, message='wrong user_id')
    
    def post(self):
        user=request.form['user']
        follower=request.form['follower']
        user=Users.query.get(user)
        following=Users.query.get(follower)
        if user and following:
            connect=Connection(user=user.user_id,following=following.user_id)
            db.session.add(connect)
            db.session.commit()
            return 'added successfully'
        else:
            abort(400,message='wrong credentials')
    
    def delete(self,user,following):
        user=Users.query.get(user)
        following=Users.query.get(following)
        if user and following:
            connect=Connection.query.filter_by(user=user.user_id,following=following.user_id).first()
            db.session.delete(connect)
            db.session.commit()
            return 'deleted successfully'
        else:
            abort(400,message='wrong credentials')

api.add_resource(Connection_api,'/api/connection','/api/connection/<int:user>', '/api/<int:user>/connection/<int:following>')

class Search_api(Resource):
    def get(self,key):
        matches=Users.query.filter(Users.username.like(f'%{key}%')).all()
        match_list=[]
        for user in matches:
            user_output_fields = {
                        'username':user.username,
                        'user_id': user.user_id,
                        'name': user.name,
                        'img': user.image,
                        'education': user.education,
                        'work': user.work,
                        'about': user.about,
                        'user_type': user.user_type
                    }
            match_list.append(user_output_fields)
        return jsonify({'matches':match_list})

api.add_resource(Search_api,'/api/search/<string:key>')

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=8080)
